#include <stdio.h>
extern "C" void app_main(void){
    printf("AI Pi-Lite Home Assistant Voice Firmware\n");
    while(true){}
}
