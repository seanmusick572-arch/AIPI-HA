# AI Pi-Lite Home Assistant Voice Firmware

Milestone 1 scaffold.
