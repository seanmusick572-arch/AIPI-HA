#pragma once
#define LCD_CS 15
#define LCD_DC 7
#define LCD_RST 18
#define LCD_BL 3
#define RGB_LED 46
#define BUTTON 42
